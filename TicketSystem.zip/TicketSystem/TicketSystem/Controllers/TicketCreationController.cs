﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using TicketSystem.Models;

namespace TicketSystem.Controllers
{
    public class TicketCreationController : Controller
    {
        [HttpGet]
        public IActionResult Index(string Id)
        {

            //string Flter = @"?query=Category="{ 0}" and  Title like "{ 1}" and  tabadul.fasah.user="{ 2}"&view=expand"
            //string Flter = $@"?query=Category=\""" + category + "\" and  Title like \"" + title + " * \" and  tabadul.fasah.user=\"" + user + "\"&view=expand";
            //  string flter = string.Concat("?query=Category=" + "\"" + category);
            //http://192.168.22.109:13080/SM/9/rest/interactions?query=Category="Fasah Incident" and  Title like "fasah*" and  tabadul.fasah.user="fasahreportinguser"&view=expand

            //var query =string.Format(@query=Category=\""" {0}\" "" and  Title like "{ 1} " and  tabadul.fasah.user="{ 2} "&view=expand" "",category,title,user);


            List<Interaction> lstInter = new List<Interaction>();
            string category = "Fasah Incident";
            string title = "fasah";
            string user = "fasahreportinguser";
            string Flter = null;
            bool IsSearch = false;
            if (string.IsNullOrEmpty(Id))
            {
                Flter = string.Concat("?query=Category=\"", "", category, "\"", " and  Title like\"", title, "*\" and tabadul.fasah.user=\"", user, "\"", "&view=expand");
                
            }
            else
            {
                Flter = $"/{Id}/";
                IsSearch = true;
            }
            HttpClientGet<RootObjectGrig> _object = new HttpClientGet<RootObjectGrig>("SM/9/rest/interactions", null, Flter);
            RootObjectGrig obj = _object.GetAll();
            if (IsSearch)
            {
                lstInter.Add(obj.Interaction);
            }
            else
            {
                Interaction lst = obj.content[0].Interaction;
                List<Content> Cobj = obj.content;
                foreach (var item in Cobj)
                {
                    lstInter.Add(item.Interaction);
                }
            }
            
            
            
            return View(lstInter);
        }

        [HttpGet]
        public IActionResult CreatTicket()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CreatTicket(Interaction Request)
        {
            HttpClientGet<RootObjectResponse> _object = new HttpClientGet<RootObjectResponse>("SM/9/rest/interactions");
            Request.AssignmentGroup = new List<string>() { "Application Support" };

            Request.Description = new List<string>() { "fasah desc" };
            RootObject obj = new RootObject();
            obj.Interaction = Request;

            RootObjectResponse rootObject = _object.PostData(obj);
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult TicketSearchById(IFormCollection form)
        {
            if (form["SearchId"].ToString() == null)
            {
                throw new Exception("Id not available");
            }
            return RedirectToAction("Index", new { id = form["SearchId"].ToString() });
        }

        public IActionResult UpdateTicket(string Id)
        {
            HttpClientGet<RootObjectGrig> _object = new HttpClientGet<RootObjectGrig>("SM/9/rest/interactions/", null, Id);
            RootObjectGrig obj = _object.GetAll();
            
            return View(obj.Interaction);
        }
        [HttpPost]
        public IActionResult UpdateTicket(Interaction Request)
        {
            if (ModelState.IsValid)
            {
                HttpClientGet<RootObjectResponse> _object = new HttpClientGet<RootObjectResponse>("SM/9/rest/interactions",null,Request.CallID);
                Request.AssignmentGroup = new List<string>() { "Application Support" };

                Request.Description = new List<string>() { "fasah desc" };
                RootObject obj = new RootObject();
                obj.Interaction = Request;

                RootObjectResponse rootObject = _object.PostData(obj);
                return RedirectToAction("Index");
            }
            else
                throw new Exception("MOdel not valid");
        }
    }
}