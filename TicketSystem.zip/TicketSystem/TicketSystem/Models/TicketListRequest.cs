﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TicketSystem.Models
{

    public class Content
    {
        public Interaction Interaction { get; set; }
    }

    public class RootObjectGrig
    {
        public int @count { get; set; }
        public int @start { get; set; }
        public int @totalcount { get; set; }
        public List<object> Messages { get; set; }
        public string ResourceName { get; set; }
        public int ReturnCode { get; set; }
        public List<Content> content { get; set; }
        public Interaction Interaction { get; set; }
    }

}
