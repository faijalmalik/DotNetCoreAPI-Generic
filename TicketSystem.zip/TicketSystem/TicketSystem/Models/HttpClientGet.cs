﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace TicketSystem.Models
{
    public class HttpClientGet<T>
    {
        
        #region property
        public string EndPoint { get; set; }

        public string Host { get; set; } 

        public string QueryStringValule { get; set; }

        public string EndPointwithParameter { get; set; }
        #endregion
               
        #region ctor
        public HttpClientGet(string endPoint)
        {
            EndPoint = endPoint ?? throw new Exception("End Point Not Define");
        }

        public HttpClientGet(string endPoint, string host)
        {

            EndPoint = endPoint ?? throw new Exception("End Point Not Define");
            Host = host ?? throw new Exception("host Not Define");
        }

        public HttpClientGet(string endPoint, string host, string queryStringValule)
        {

            EndPoint = endPoint ?? throw new Exception("End Point Not Define");
            QueryStringValule = queryStringValule ?? throw new Exception("End Point Not Define");
            if (!string.IsNullOrEmpty(host))
                Host = host ?? throw new Exception("host Not Define");
        }
        public HttpClientGet(int a) : base()
        {

        }
        #endregion


        public T GetAll()
        {
            T data = default(T);

            using (var client = new HttpClient())
            {
                //Basic AUthorization  if not required remove it

                var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("xxx:xxx");
                string val = System.Convert.ToBase64String(plainTextBytes);
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);
                //ENd   

                client.BaseAddress = new Uri(Host);
                if (string.IsNullOrEmpty(QueryStringValule))
                {
                    EndPointwithParameter = EndPoint;
                }
                else
                {
                    EndPointwithParameter = EndPoint + QueryStringValule;
                    if (EndPointwithParameter.Contains("'")) {
                        EndPointwithParameter = EndPointwithParameter.Replace("'","\"");
                    }
                }
                var responseTask = client.GetAsync(EndPointwithParameter);
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    var readTask = result.Content.ReadAsStringAsync();
                    string jsonString = readTask
                                        .Result
                                        .Replace("\\", "")
                                        .Trim(new char[1] { '"' });

                    data = JsonConvert.DeserializeObject<T>(jsonString);
                }
                else
                {
                    if (result.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                    {
                        //
                    }

                }
            }

            return data;
        }

        public  T PostData(object data)
        {
            T o = default(T);
            var json = JsonConvert.SerializeObject(data);
            var stringdata = new StringContent(json, Encoding.UTF8, "application/json");
            using var client = new HttpClient();

            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("xxx:xxx");
            string val = System.Convert.ToBase64String(plainTextBytes);
            client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);

            var response = client.PostAsync(Host+EndPoint, stringdata);

            var result = response.Result;
            if (result.StatusCode == HttpStatusCode.OK)
            {



                string jsonString = result.Content.ReadAsStringAsync().Result
                                            .Replace("\\", "")
                                            .Trim(new char[1] { '"' });

                o = JsonConvert.DeserializeObject<T>(jsonString);
                

            }
            return o;
        }

        //public T GetAllWithParameter()
        //{
        //    T data = default(T);

        //    using (var client = new HttpClient())
        //    {
        //        //Basic AUthorization  if not required remove it
        //        var plainTextBytes = System.Text.Encoding.UTF8.GetBytes("admin:admin");
        //        string val = System.Convert.ToBase64String(plainTextBytes);
        //        client.DefaultRequestHeaders.Add("Authorization", "Basic " + val);
        //        //ENd   

        //        client.BaseAddress = new Uri(Host);
        //        var responseTask = client.GetAsync(EndPoint);
        //        responseTask.Wait();

        //        var result = responseTask.Result;
        //        if (result.IsSuccessStatusCode)
        //        {

        //            var readTask = result.Content.ReadAsStringAsync();
        //            string jsonString = readTask
        //                                .Result
        //                                .Replace("\\", "")
        //                                .Trim(new char[1] { '"' });

        //            data = JsonConvert.DeserializeObject<T>(jsonString);
        //        }
        //        else
        //        {
        //            if (result.StatusCode == System.Net.HttpStatusCode.Unauthorized)
        //            {
        //                //
        //            }

        //        }
        //    }

        //    return data;
        //}


    }
}
