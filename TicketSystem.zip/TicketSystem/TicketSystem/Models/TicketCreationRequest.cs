﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace TicketSystem.Models
{
    public class Interaction : Response
    {
        public string AffectedService { get; set; }
        public string Area { get; set; }
        public List<string> AssignmentGroup { get; set; }
        public string CallerDepartment { get; set; }
        public string Category { get; set; }
        public string Contact { get; set; }
        public List<string> Description { get; set; }
        public string Impact { get; set; }
        public string NotifyBy { get; set; }
        public string ServiceRecipient { get; set; }
        public string TabadulCustType { get; set; }
        public string Tabadulissue { get; set; }
        public string TabadulissueAR { get; set; }
        public string Tabadulservice { get; set; }
        public string Tabadulsubservice { get; set; }
        //  public string __invalid_name__tabadul.fasah.user { get; set; }
        public string Title { get; set; }
        public string Urgency { get; set; }

        public List<string> Update { get; set; }

    }

    public class Response
    {
        public DateTime? UpdateTime { get; set; }
        public string Status { get; set; }

        public bool SLABreached { get; set; }
        public string Priority { get; set; }
        public string Phase { get; set; }
        public string OpenedBy { get; set; }
        public string CallID { get; set; }

        public string CallOwner { get; set; }
        public DateTime? OpenTime { get; set; }

        public DateTime? NextSLABreach { get; set; }
        public bool KnowledgeCandidate { get; set; }

    }

    public class RootObject
    {
        public Interaction Interaction { get; set; }
    }

    public class RootObjectResponse
    {
        public Interaction Interaction { get; set; }
        public List<string> Messages { get; set; }
        public int ReturnCode { get; set; }
    }

   
}
